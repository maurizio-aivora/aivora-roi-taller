import { ROICalculator } from "@/components/calculator/ROICalculator";

const Index = () => {
  return <ROICalculator />;
};

export default Index;
